﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace HISPlus
{
    public delegate void DataChanged();

    public class FormDo: Form
    {
        #region 变量
        protected string _id;                   // 窗体ID
        protected string _version;              // 版本号
        protected string _guid;                 // 窗体的GUID
        protected string _right;                // 支持的权限
        protected string _userRight;            // 当前用户具有权限
        #endregion

        /// <summary>
        /// FormDo 摘要说明
        /// </summary>
        public FormDo()
        {
            this.KeyPreview = true;

            this.KeyDown += new KeyEventHandler(FormDo_KeyDown);
            this.MouseUp += new MouseEventHandler(FormDo_MouseUp);
        }


        #region 属性
        /// <summary>
        /// 功能划分ID
        /// </summary>
        public string ID
        {
            get
            {
                return _id;
            }
        }


        /// <summary>
        /// 版本号
        /// </summary>
        public string Version
        {
            get
            {
                return _version;
            }
        }


        /// <summary>
        /// 窗体GUID
        /// </summary>
        public string GUID
        {
            get 
            { 
                return _guid;
            }
        }


        /// <summary>
        /// 窗体支持的权限列表
        /// </summary>
        public string Right
        {
            get
            {
                return _right;
            }
        }


        /// <summary>
        /// 当前用户的权限
        /// </summary>
        public string UserRight
        {
            get
            {
                return _userRight;
            }
            set
            {
                _userRight = value;
            }
        }
        #endregion


        #region 方法
        void FormDo_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.KeyCode == Keys.F11)
                {
                    FormDoInfo infoFrm = new FormDoInfo();
                    infoFrm.ShowFormInfo(_id, _version, _guid, _right, _userRight);

                    infoFrm.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                Error.ErrProc(ex);
            }  
        }


        void FormDo_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                Keys keyMode = Control.ModifierKeys;

                if (e.Button == MouseButtons.Right && keyMode == (Keys.Control))
                {
                    FormDoInfo infoFrm = new FormDoInfo();
                    infoFrm.ShowFormInfo(_id, _version, _guid, _right, _userRight);

                    infoFrm.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                Error.ErrProc(ex);
            }
        }
        #endregion
    }
}
